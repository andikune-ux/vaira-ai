Paket ekspor File storage V A I R A AI.

Isi folder storage berisi objek yang berhasil diunduh dari referensi database. manifest.json memuat sumber, metadata, dan status ekspor setiap objek. URL bertanda tangan tidak dijadikan nama file dan tidak dimasukkan ke SQL.
